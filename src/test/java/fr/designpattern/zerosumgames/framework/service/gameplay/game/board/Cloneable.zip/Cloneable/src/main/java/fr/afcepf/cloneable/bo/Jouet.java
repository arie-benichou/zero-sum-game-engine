package fr.afcepf.cloneable.bo;

public class Jouet implements Cloneable {

  private String nom;
  
  public Jouet(String nom) {
    this.nom = nom;
  }
  
  public Jouet clone() {
    Jouet jouet = null;
    try {
      // On récupère l'instance à renvoyer par l'appel de la 
      // méthode super.clone()
      jouet = (Jouet) super.clone();
    } catch(CloneNotSupportedException cnse) {
      // Ne devrait jamais arriver car nous implémentons 
      // l'interface Cloneable
      cnse.printStackTrace(System.err);
    }
    // on renvoie le clone
    return jouet;
  }
  
  public String getNom() {
	return nom;
  }
  
  public void setNom(String nom) {
	this.nom = nom;
  }
}
