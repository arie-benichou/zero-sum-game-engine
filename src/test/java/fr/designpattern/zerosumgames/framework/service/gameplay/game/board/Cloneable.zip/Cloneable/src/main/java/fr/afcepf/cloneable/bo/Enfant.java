package fr.afcepf.cloneable.bo;

public class Enfant extends Personne {

	private Jouet jouetPrefere;

	public Enfant(Patronyme patronyme, int age, Jouet jouetPrefere) {
		super(patronyme, age);
		this.jouetPrefere = jouetPrefere;
	}

	public Enfant clone() {
		// On récupère l'instance à renvoyer par l'appel de la
		// méthode super.clone() (ici : Personne.clone())
		Enfant enfant = (Enfant) super.clone();

		// On clone l'attribut de type Jouet qui n'est pas immuable.
		enfant.jouetPrefere = (Jouet) jouetPrefere.clone();

		// on renvoie le clone
		return enfant;
	}

	public Jouet getJouetPrefere() {
		return jouetPrefere;
	}

	public void setJouetPrefere(Jouet jouetPrefere) {
		this.jouetPrefere = jouetPrefere;
	}

	@Override //
	public int hashCode() { // TODO à overrider également dans Jouet et Patronyme
		
		int hashCode = 17;
		
		hashCode *= 31;
		hashCode += this.getPatronyme().hashCode();
		
		hashCode *= 31;
		hashCode += this.getPatronyme().hashCode();
		
		hashCode *= 31;
		hashCode += this.getJouetPrefere().hashCode();
		
		hashCode *= 31;
		hashCode += this.getAge();
		
		return hashCode;
	}

	@Override
	public boolean equals(Object obj) { // TODO à overrider également dans Jouet et Patronyme
		final boolean isEqual;
		if (obj == this) {
			isEqual = true;
		}
		else  if (obj == null) {
			isEqual = false;
		}
		else if (!(obj instanceof Enfant)) {
			isEqual = true;
		}
		else {
			Enfant enfant = (Enfant) obj;
			if(obj.hashCode() != this.hashCode()) {
				isEqual = false;
			}
			else {
				isEqual =
					enfant.getAge() == this.getAge()
					&&
					enfant.getJouetPrefere().equals(this.getJouetPrefere())
					&&
					enfant.getPatronyme().equals(this.getPatronyme())
				; 
			}
		}
		return isEqual;
	}

}