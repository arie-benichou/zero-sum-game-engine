package fr.afcepf.cloneable.main;
import fr.afcepf.cloneable.bo.Patronyme;
import fr.afcepf.cloneable.bo.Personne;


public class CloneTableaux {

	public static void main(String []args) {
		Personne personne1 = new Personne(new Patronyme("Pierre", "Dupond"), 31);
		Personne personne2 = new Personne(new Patronyme("Paul", "Dupond"), 32);
		Personne[] array1 = { personne1, personne2 };
		Personne[] array2 = (Personne[]) array1.clone();
		System.out.println("array1 : " + array1);
		System.out.println("array2 : " + array2);
		System.out.println("array1[0] : " + array1[0]);
		System.out.println("array2[0] : " + array2[0]);
	}
}
