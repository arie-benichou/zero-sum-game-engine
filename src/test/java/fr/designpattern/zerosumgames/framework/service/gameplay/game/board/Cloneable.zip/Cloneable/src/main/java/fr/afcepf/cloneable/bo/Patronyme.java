package fr.afcepf.cloneable.bo;

public class Patronyme implements Cloneable {

  private String prenom;
  private String nom;
  
  public Patronyme(String prenom, String nom) {
    this.prenom = prenom;
    this.nom = nom;
  }
  
  public Patronyme clone() {
    Patronyme patronyme = null;
    try {
      // On récupère l'instance à renvoyer par l'appel de la 
      // méthode super.clone()
      patronyme = (Patronyme) super.clone();
    } catch(CloneNotSupportedException cnse) {
      // Ne devrait jamais arriver car nous implémentons 
      // l'interface Cloneable
      cnse.printStackTrace(System.err);
    }
    // on renvoie le clone
    return patronyme;
  }
  
  public String getPrenom() {
    return prenom;
  }
  
  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }
  
  public String getNom() {
    return nom;
  }
  
  public void setNom(String nom) {
    this.nom = nom;
  }
  
  public String toString() {
    return prenom + " " + nom;
  }
}
