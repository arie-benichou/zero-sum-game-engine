package fr.afcepf.cloneable.main;
import fr.afcepf.cloneable.bo.Enfant;
import fr.afcepf.cloneable.bo.Jouet;
import fr.afcepf.cloneable.bo.Patronyme;
import fr.afcepf.cloneable.bo.Personne;


public class CloneMain {

  public static void main(String []args) {
    Personne personne1 = new Personne(new Patronyme("Jean", "Dupond"), 30);
    Personne personne2 = personne1.clone();
    System.out.println(personne1);
    System.out.println(personne2);
    Enfant enfant1 = new Enfant(new Patronyme("Pierre", "Dupond"), 10, new Jouet("Teddy bear"));
    Enfant enfant2 = enfant1.clone();
    System.out.println(enfant1);
    System.out.println(enfant2);
  }
}
