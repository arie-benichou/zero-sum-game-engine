package fr.afcepf.cloneable.bo;

public class Personne implements Cloneable {

  private Patronyme patronyme;
  private int age;
  
  public Personne(Patronyme patronyme, int age) {
    this.patronyme = patronyme;
    this.age = age;
  }
  
  public Personne clone() {
    Personne personne = null;
    try {
      // On récupère l'instance à renvoyer par l'appel de la 
      // méthode super.clone()
      personne = (Personne) super.clone();
    } catch(CloneNotSupportedException cnse) {
      // Ne devrait jamais arriver car nous implémentons 
      // l'interface Cloneable
      cnse.printStackTrace(System.err);
    }
    
    // On clone l'attribut de type Patronyme qui n'est pas immuable.
    personne.patronyme = patronyme.clone();
    
    // on renvoie le clone
    return personne;
  }
  
  public Patronyme getPatronyme() {
    return patronyme;
  }
  
  public void setPatronyme(Patronyme patronyme) {
	this.patronyme = patronyme;
  }
  
  public int getAge() {
    return age;
  }
  
  public void setAge(int age) {
	this.age = age;
  }
}
