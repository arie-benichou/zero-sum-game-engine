package fr.afcepf.cloneable.bo.test;

import static junit.framework.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import fr.afcepf.cloneable.bo.Enfant;
import fr.afcepf.cloneable.bo.Jouet;
import fr.afcepf.cloneable.bo.Patronyme;

public class TestEnfant {
	
	private Enfant enfant;
	
	@Before
	public void setUp() throws Exception {
		final Patronyme patronyme = new Patronyme("Arié", "Bénichou"); 
		final Jouet jouet = new Jouet("GameBoy");
		final int age = 10;
		this.enfant = new Enfant(patronyme, age, jouet);
	}

	@After
	public void tearDown() throws Exception {}

	@Test
	public void testClone() {
		
		final Enfant enfantclone = this.enfant.clone();
		
		assertNotSame(enfantclone.getPatronyme(), enfant.getPatronyme());
			assertEquals(enfantclone.getPatronyme().getPrenom(), enfant.getPatronyme().getPrenom());		
			assertEquals(enfantclone.getPatronyme().getNom(), enfant.getPatronyme().getNom());

		assertNotSame(enfantclone.getJouetPrefere(), enfant.getJouetPrefere());
			assertEquals(enfantclone.getJouetPrefere().getNom(), enfant.getJouetPrefere().getNom());
		
		assertEquals(enfantclone.getAge(), enfant.getAge());
		
	}

}
